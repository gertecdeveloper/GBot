package com.gertec.exemplosgertec;

public class GlobalValues {
    public static String codAtivacao = "";
    public static String ultimaChaveVenda = "";
}
