package com.gertec.exemplosgertec;

/**
 * Created by Administrator
 *
 * @author 猿史森林
 *         Date: 2019/9/21
 *         Class description:
 */
public interface ConnectState {
    void success();
}
