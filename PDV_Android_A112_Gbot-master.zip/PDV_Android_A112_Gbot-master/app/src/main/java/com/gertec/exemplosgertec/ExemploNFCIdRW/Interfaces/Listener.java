package com.gertec.exemplosgertec.ExemploNFCIdRW.Interfaces;

public interface Listener {

    void onDialogDisplayed();

    void onDialogDismissed();

}
